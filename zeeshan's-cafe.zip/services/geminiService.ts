// Service no longer required for Restaurant Menu Website
export const getSmartTimerConfig = async () => { return null; }